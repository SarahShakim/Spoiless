banana = []
apple = []
