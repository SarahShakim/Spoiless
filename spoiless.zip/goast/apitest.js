var unirest = require("unirest");

var req = unirest("GET", "https://feeditem-walmart.p.rapidapi.com/itemID/30117194");

req.headers({
	"x-rapidapi-key": "SIGN-UP-FOR-KEY",
	"x-rapidapi-host": "feeditem-walmart.p.rapidapi.com",
	"useQueryString": true
});


req.end(function (res) {
	//if (res.error) throw new Error(res.error);

	console.log(res.body);
});
