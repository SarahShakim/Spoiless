import pytesseract
import re
amount = True
grocery = []
pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract'
extracted_text = pytesseract.image_to_string(r'C:\Users\User\Desktop\machacks\goast\walmart2.jpg')
receipt_ocr = {}

product_pattern = (r'([0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9])')
#product =[x.group() for x in re.finditer("product_pattern",extracted_text )]
product = re.findall(product_pattern, extracted_text)
print(product)
